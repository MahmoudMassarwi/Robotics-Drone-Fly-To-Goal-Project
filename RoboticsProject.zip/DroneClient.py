import airsim
import DroneTypes
import time
import math

class DroneClient:
    def __init__(self):
        self.client = airsim.MultirotorClient()
        self.future = None

    def __del__(self):
        if self.future is not None:
            self.future.join()

    def connect(self):
        """
        Connect to simulation

        Args:
            none

        Returns:
            none
        """
        self.client.confirmConnection()
        self.client.enableApiControl(True)
        self.client.armDisarm(True)

    def isConnected(self):
        """
        Check if client is connected to simulation

        Args:
            none

        Returns:
            bool: true if connected. otherwise return false
        """
        return self.client.isApiControlEnabled()

    def getPose(self):
        """
        Get the pose of the drone

        Args:
            none

        Returns:
            DroneTypes.Pose : the pose of the drone
        """
        drone_pose = self.client.simGetVehiclePose()
        res = DroneTypes.Pose()

        res.pos.x_m = drone_pose.position.x_val
        res.pos.y_m = drone_pose.position.y_val
        res.pos.z_m = drone_pose.position.z_val

        euler = airsim.utils.to_eularian_angles(drone_pose.orientation)

        res.orientation.x_rad = euler[0]
        res.orientation.y_rad = euler[1]
        res.orientation.z_rad = euler[2]

        return res

    def getLidarData(self):
        point_cloud = DroneTypes.PointCloud()
        lidar_data = self.client.getLidarData()

        point_cloud.points = lidar_data.point_cloud

        return point_cloud

    def flyToPosition(self, x: float, y: float, z: float, v: float):
        """
        Fly the drone to position

        Args:
            x : float - x coordinate
            y : float - y coordinate
            z : float - z coordinate
            v : float - the velocity which the drone fly to position

        Returns:
            none
        """
        self.future = self.client.moveToPositionAsync(x, y, z, v, drivetrain=airsim.DrivetrainType.ForwardOnly,
                                                      yaw_mode=airsim.YawMode(False, 0.0))

    def setAtPosition(self, x: float, y: float, z: float):
        """
        Set the drone at position instantly

        Args:
            x : float - x coordinate
            y : float - y coordinate
            z : float - z coordinate

        Returns:
            none
        """
        pos = airsim.Vector3r(x, y, z)
        q = airsim.Quaternionr(1, 0, 0, 0)
        pose = airsim.Pose(pos, q)

        self.client.simSetVehiclePose(pose, True)
        self.flyToPosition(x, y, z, 1)

    def reset(self):
        """
        Returns the drone to start position

        Args:
            none

        Returns:
            none
        """
        self.client.reset()

#-------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------
########################################OUR_FUNCTIONS#################################################
########################################OUR_FUNCTIONS#################################################
########################################OUR_FUNCTIONS#################################################



def calc_distance(my_x, my_y, obstacle_x, obstacle_y):
    return math.sqrt(math.pow((my_x - obstacle_x), 2) + math.pow((my_y - obstacle_y), 2))


def danger_zone(my_x, my_y, obstacle_x, obstacle_y, min_distance):
    tmp = calc_distance(my_x, my_y, obstacle_x, obstacle_y)
    # print("distance isssssssssssss", tmp)
    if tmp < min_distance:
        return True
    else:
        return False


def dicrection_to_safety(my_x, my_y, obstacle_x, obstacle_y):
    if obstacle_x > my_x:
        x_mul = -1
    else:
        x_mul = 1

    if obstacle_y > my_y:
        y_mul = -1
    else:
        y_mul = 1

    distance = calc_distance(my_x, my_y, obstacle_x, obstacle_y)
    diff_in_x = abs(my_x - obstacle_x)
    diff_in_y = abs(my_y - obstacle_y)
    speed_direction_for_x = (diff_in_x / distance) * x_mul
    speed_direction_for_y = (diff_in_y / distance) * y_mul
    speed_direction_array = [speed_direction_for_x, speed_direction_for_y]
    return speed_direction_array


def convert_to_unity_vector(vector_x, vector_y):
    distance = calc_distance(0, 0, vector_x, vector_y)
    unity_vector_x = vector_x / distance
    unity_vector_y = vector_y / distance
    unity_vector_result = [unity_vector_x, unity_vector_y]
    return unity_vector_result


def direction_to_goal(my_x, my_y, goal_x, goal_y):
    if goal_x > my_x:
        x_mul = 1
    else:
        x_mul = -1

    if goal_y > my_y:
        y_mul = 1
    else:
        y_mul = -1

    distance = calc_distance(my_x, my_y, goal_x, goal_y)
    diff_in_x = abs(my_x - goal_x)
    diff_in_y = abs(my_y - goal_y)
    speed_direction_for_x = (diff_in_x / distance) * x_mul
    speed_direction_for_y = (diff_in_y / distance) * y_mul
    speed_direction_array = [speed_direction_for_x, speed_direction_for_y]
    return speed_direction_array


def direction_to_side_walk(move_x, move_y, goal_x, goal_y):
    tmp2 = math.sqrt(1 / (1 + (math.pow(move_y / move_x, 2))))
    tmp1 = (- (tmp2 * move_y)) / move_x
    tmp4 = - tmp2
    tmp3 = - tmp1
    direction = [0, 0]
    if calc_distance(tmp3, tmp4, goal_x, goal_y) <= calc_distance(tmp1, tmp2, goal_x, goal_y):
        direction[0] = tmp3
        direction[1] = tmp4
    else:
        direction[0] = tmp1
        direction[1] = tmp2
    return direction


def obstacle_avoidance_zone(my_x, my_y, obstacle_x, obstacle_y, min_distance, avoidance_bubble_distance):
    tmp = calc_distance(my_x, my_y, obstacle_x, obstacle_y)
    if avoidance_bubble_distance >= tmp >= min_distance:
        return True
    else:
        return False


def obstacle_avoidance_direction(my_x, my_y, obstacle_x, obstacle_y, goal_direction_x, goal_direction_y):
    direction_to_obstacle = dicrection_to_safety(my_x, my_y, obstacle_x, obstacle_y)
    direction_to_obstacle[0] = -direction_to_obstacle[0]
    direction_to_obstacle[1] = -direction_to_obstacle[1]
    avoidance_directions = direction_to_side_walk(direction_to_obstacle[0], direction_to_obstacle[1], goal_direction_x,
                                                  goal_direction_y)
    return avoidance_directions


#######################################OUR_FUNCTIONS_END###################################################
#######################################OUR_FUNCTIONS_END###################################################
#######################################OUR_FUNCTIONS_END###################################################


def  fly_to_goal(given_start_x,given_start_y,given_finish_x,given_finish_y,given_height):
    client = DroneClient()
    client.connect()

    print(client.isConnected())
    time.sleep(4)
    height_of_flight = given_height
    client.setAtPosition(given_start_x, given_start_y, height_of_flight)
    # fly to -800,-600
    # I want it to fly in height in the negative direction in Y
    # client.flyToPosition(-346, -420, -100, 10)
    while not (height_of_flight - 2 <= client.getPose().pos.z_m <= height_of_flight + 2):
        time.sleep(1)
        continue
    ########################## NOW WE CAN START OUR PLANNED TRAJECTORY : ############################
    ####################################### DRONE_PARAMETERS ########################################
    goal_x = given_finish_x
    goal_y = given_finish_y
    drone_height = height_of_flight
    arrived_distance = 5
    avoidance_speed_factor = 5
    min_distance_from_obstacle = 5  # for danger zone
    escaping_obstacle_distance = 8  # for exiting danger zone
    avoidance_bubble = 30  # avoidance zone = min_distance_from_obstacle - avoidance bubble
    finish_counter = 150
    speed_of_avoidance = 2
    turbo_speed = 5
    escaping_danger_speed = 3
    min_safe_measures_for_safety = 15
    back_to_safety_counter = min_safe_measures_for_safety
    ##################################
    move_x = 0
    move_y = 0
    avoidance_move_x = 0
    avoidance_move_y = 0
    drone_speed = speed_of_avoidance
    obstacle_x = 0
    obstacle_y = 0
    obstacle_z = 0
    obstacle_flag = False
    danger_flag = False
    arrived_to_goal_flag = False
    last_danger_point = [0, 0]
    ####################################### DRONE_PARAMETERS_END ######################################
    while not (arrived_to_goal_flag and finish_counter == 0):
        ###### CHECKING DRONE AND OBSTACLE POSITIONS: #######
        lidarData = client.getLidarData()
        droneData = client.getPose()
        drone_x = droneData.pos.x_m
        drone_y = droneData.pos.y_m
        drone_z = droneData.pos.z_m

        if len(lidarData.points) != 1:
            Theta = droneData.orientation.z_rad
            obstacle_x = (math.cos(Theta) * lidarData.points[0] - math.sin(Theta) * lidarData.points[1]) + drone_x
            obstacle_y = (math.sin(Theta) * lidarData.points[0] + math.cos(Theta) * lidarData.points[1]) + drone_y
            print(" the next obstacle x is", obstacle_x)
            print(" the next obstacle y is ", obstacle_y)
            obstacle_z = lidarData.points[2] + drone_z
        ###### CHECKING DRONE AND OBSTACLE POSITIONS END: #######

        ###### CALCULATING THE DIRECTION FROM THE DRONE TO GOAL:
        goalDirection = direction_to_goal(drone_x, drone_y, goal_x, goal_y)  # returns speed direction array#
        if danger_flag:
            drone_speed = escaping_danger_speed
            if calc_distance(drone_x, drone_y, last_danger_point[0],
                             last_danger_point[1]) >= escaping_obstacle_distance:
                danger_flag = False

        else:
            move_x = goalDirection[0]
            move_y = goalDirection[1]
            if back_to_safety_counter == min_safe_measures_for_safety:
                drone_speed = turbo_speed
            else:
                drone_speed = speed_of_avoidance

        ##################### PRINTING THE DRONE POSITION AND ORIENTATION AND THE LIDAR READING ########################

        print(droneData)
        # print(lidarData.points)
        # print("move x: ", move_x)
        # print("move y: ", move_y)
        ############################################################################################################
        if len(lidarData.points) != 1:
            if danger_zone(drone_x, drone_y, obstacle_x, obstacle_y, min_distance_from_obstacle):
                print("DANGEEEEER!")
                print("DANGEEEEER!")
                print("DANGEEEEER!")
                print("DANGEEEEER!")
                print("DANGEEEEER!")
                print("DANGEEEEER!")
                print("DANGEEEEER!")
                print("DANGEEEEER!")
                print("-----------")

                safety_direction_array = dicrection_to_safety(drone_x, drone_y, obstacle_x, obstacle_y)
                move_x = safety_direction_array[0]
                move_y = safety_direction_array[1]
                danger_flag = True
                obstacle_flag = False
                avoidance_move_x = 0
                avoidance_move_y = 0
                back_to_safety_counter = 0

                last_danger_point[0] = obstacle_x
                last_danger_point[1] = obstacle_y
            elif obstacle_avoidance_zone(drone_x, drone_y, obstacle_x, obstacle_y, min_distance_from_obstacle,
                                         avoidance_bubble):
                drone_speed = speed_of_avoidance
                back_to_safety_counter = 0

                side_directions = [0, 0]

                Fov_Deg = droneData.orientation.z_rad
                fov_x = (math.cos(Fov_Deg) * 1 - math.sin(Fov_Deg) * 0)
                fov_y = (math.sin(Fov_Deg) * 1 + math.cos(Fov_Deg) * 0)

                tmp = math.sin(math.pi / 4)

                fov_right_x = (math.cos(Fov_Deg) * tmp - math.sin(Fov_Deg) * tmp)
                fov_right_y = (math.sin(Fov_Deg) * tmp + math.cos(Fov_Deg) * tmp)
                fov_left_x = (math.cos(Fov_Deg) * tmp - math.sin(Fov_Deg) * -tmp)
                fov_left_y = (math.sin(Fov_Deg) * tmp + math.cos(Fov_Deg) * -tmp)

                if (0 <= lidarData.points[1] <= lidarData.points[0]) or (
                        lidarData.points[1] < 0 and -lidarData.points[1] <= lidarData.points[0]):
                    side_directions = obstacle_avoidance_direction(drone_x, drone_y, drone_x + fov_x, drone_y + fov_y,
                                                                   goalDirection[0], goalDirection[1])

                elif (0 <= lidarData.points[1]) and (lidarData.points[1] > lidarData.points[0]):
                    side_directions = obstacle_avoidance_direction(drone_x, drone_y, drone_x + fov_right_x,
                                                                   drone_y + fov_right_y, fov_x, fov_y)

                elif (lidarData.points[1] < 0) and (-lidarData.points[1] > lidarData.points[0]):
                    side_directions = obstacle_avoidance_direction(drone_x, drone_y, drone_x + fov_left_x,
                                                                   drone_y + fov_left_y, fov_x, fov_y)

                obstacle_flag = True
                avoidance_move_x = side_directions[0]
                avoidance_move_y = side_directions[1]
                print("AVOOOOIDAAAANCE!")
                print("AVOOOOIDAAAANCE!")
                print("AVOOOOIDAAAANCE!")
                print("AVOOOOIDAAAANCE!")
            else:
                if back_to_safety_counter != min_safe_measures_for_safety:
                    back_to_safety_counter += 1
                    drone_speed = speed_of_avoidance
                else:
                    obstacle_flag = False
                    drone_speed = turbo_speed
        else:
            if back_to_safety_counter != min_safe_measures_for_safety:
                back_to_safety_counter += 1
                drone_speed = speed_of_avoidance
            else:
                obstacle_flag = False
                drone_speed = turbo_speed

        ######################################## FLYYYYYYING ^____^  ###################################################

        next_x = drone_x + (move_x + avoidance_move_x * avoidance_speed_factor * obstacle_flag) * drone_speed
        # print("move x vector: ", next_x - drone_x)
        next_y = drone_y + (move_y + avoidance_move_y * avoidance_speed_factor * obstacle_flag) * drone_speed
        # print("move y vector: ", next_y - drone_y)

        movement_vector = convert_to_unity_vector(next_x - drone_x, next_y - drone_y)
        print("direction of movement is: ", movement_vector)

        # -----------------------
        if arrived_to_goal_flag:
            drone_speed = 1
        print("________________________")
        print("MY SPEEEED ISSSSSSSSS : ", drone_speed)
        print("________________________")
        # -----------------------

        client.flyToPosition(next_x, next_y, drone_height + 1, drone_speed)

        ############################################################################################################

        if calc_distance(drone_x, drone_y, goal_x, goal_y) <= arrived_distance:
            print("WE HAVE ARRIVED ^_____^ YAAAAAAY!")
            print("WE HAVE ARRIVED ^_____^ YAAAAAAY!")
            print("WE HAVE ARRIVED ^_____^ YAAAAAAY!")
            print("WE HAVE ARRIVED ^_____^ YAAAAAAY!")
            print("WE HAVE ARRIVED ^_____^ YAAAAAAY!")
            arrived_to_goal_flag = True
            finish_counter -= 1

        time.sleep(0.04)

# This is the version 1.5 solution
# in this version we added back to safety counter which allows the
# avoidance flag  effect longer time
# we added detecting angel and move accordingly
# added speed control (there is a need for better speed control than this)
# NOTE:  THE TURBO SPEED SHOULD BE SMALLER BUT THIS IS JUST FOR FUN
# Added stopping when reaching the goal
# In this version we arrange the code to look better and easier to control the flight parameters
