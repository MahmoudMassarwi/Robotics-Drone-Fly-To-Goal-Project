from DroneClient import DroneClient
from DroneClient import fly_to_goal

import time
import math
import airsim.utils



if __name__ == "__main__":
    fly_to_goal(-280,-710,-240,-1100,-68)