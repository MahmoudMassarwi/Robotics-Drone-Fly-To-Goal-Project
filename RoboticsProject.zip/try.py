import math


def calc_distance(my_x, my_y, obstacle_x, obstacle_y):
    return math.sqrt(math.pow((my_x - obstacle_x), 2) + math.pow((my_y - obstacle_y), 2))


def danger_zone(my_x, my_y, obstacle_x, obstacle_y, min_distance):
    if calc_distance(my_x, my_y, obstacle_x, obstacle_y) < min_distance:
        return True
    else:
        return False


def dicrection_to_safety(my_x, my_y, obstacle_x, obstacle_y):
    if obstacle_x > my_x:
        x_mul = -1
    else:
        x_mul = 1

    if obstacle_y > my_y:
        y_mul = -1
    else:
        y_mul = 1

    distance = calc_distance(my_x, my_y, obstacle_x, obstacle_y)
    diff_in_x = abs(my_x - obstacle_x)
    diff_in_y = abs(my_y - obstacle_y)
    speed_direction_for_x = (diff_in_x / distance) * x_mul
    speed_direction_for_y = (diff_in_y / distance) * y_mul
    speed_direction_array = [speed_direction_for_x, speed_direction_for_y]
    return speed_direction_array


def direction_to_goal(my_x, my_y, goal_x, goal_y):
    if goal_x > my_x:
        x_mul = 1
    else:
        x_mul = -1

    if goal_y > my_y:
        y_mul = 1
    else:
        y_mul = -1

    distance = calc_distance(my_x, my_y, goal_x, goal_y)
    diff_in_x = abs(my_x - goal_x)
    diff_in_y = abs(my_y - goal_y)
    speed_direction_for_x = (diff_in_x / distance) * x_mul
    speed_direction_for_y = (diff_in_y / distance) * y_mul
    speed_direction_array = [speed_direction_for_x, speed_direction_for_y]
    return speed_direction_array


def direction_to_side_walk(move_x, move_y, goal_x, goal_y):
    tmp2 = math.sqrt(1 / (1 + (math.pow(move_y / move_x, 2))))
    tmp1 = (- (tmp2 * move_y)) / move_x
    tmp4 = - tmp2
    tmp3 = - tmp1
    direction = [0, 0]
    if calc_distance(tmp3, tmp4, goal_x, goal_y) <= calc_distance(tmp1, tmp2, goal_x, goal_y):
        direction[0] = tmp3
        direction[1] = tmp4
    else:
        direction[0] = tmp1
        direction[1] = tmp2
    return direction


s_d_a = direction_to_goal(0, 0, 1, -3)
print("x direction is ", s_d_a[0])
print("y direction is ", s_d_a[1])

direction = direction_to_side_walk(1, -3, 1, -1)
print("x side direction is ", direction[0])
print("y side direction is ", direction[1])


def convert_to_unity_vector(vector_x, vector_y):
    distance = calc_distance(0, 0, vector_x, vector_y)
    unity_vector_x = vector_x / distance
    unity_vector_y = vector_y / distance
    unity_vector_result = [unity_vector_x, unity_vector_y]
    return unity_vector_result


print("###############################")
print("###############################")
print("###############################")
print("###############################")
converted = convert_to_unity_vector(-12, -3)
print(converted)

reversed(list(range(1, 10)))

number = 3


numbers = [2,'apple',3.5]
number['orrange'] = 1

print("hhhhhhhhhhhhhhhhhhhhhhhhhhhh")
print(numbers[1])

